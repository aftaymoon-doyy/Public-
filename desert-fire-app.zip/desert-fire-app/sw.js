// ============================================
// Desert Fire - Service Worker
// كل ما ترفع تحديث على GitHub يتحدث تلقائياً
// ============================================

const CACHE_NAME = 'desert-fire-v1'; // غيّر الرقم عند كل تحديث
const FILES_TO_CACHE = [
  './game.html',
  './manifest.json',
  './icon-192.png',
  './icon-512.png'
];

// تثبيت: cache الملفات
self.addEventListener('install', event => {
  console.log('[SW] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      console.log('[SW] Caching files');
      return cache.addAll(FILES_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// تفعيل: امسح الـ cache القديم
self.addEventListener('activate', event => {
  console.log('[SW] Activating...');
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(key => key !== CACHE_NAME).map(key => {
          console.log('[SW] Deleting old cache:', key);
          return caches.delete(key);
        })
      )
    )
  );
  self.clients.claim();
});

// Fetch: Network First (دايماً يجيب أحدث نسخة من النت)
// لو مفيش نت يستخدم الـ cache
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request)
      .then(response => {
        // خزّن النسخة الجديدة في الـ cache
        if (response && response.status === 200) {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then(cache => {
            cache.put(event.request, responseClone);
          });
        }
        return response;
      })
      .catch(() => {
        // لو مفيش نت، استخدم الـ cache
        return caches.match(event.request);
      })
  );
});

// استقبال رسائل من اللعبة
self.addEventListener('message', event => {
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
  }
});
